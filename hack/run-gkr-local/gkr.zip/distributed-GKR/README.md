# distributed-GKR

Rust implementation of distributed GKR interactive protocol.
