#!/bin/bash

exponent=19
result=512

echo "Powers of 2 up to 2^$exponent:"

# Create an array to store the powers of 2
powers_of_2=()

for ((i = 9; i <= exponent; i++)); do
    powers_of_2+=($result)
    echo "2^$i = $result"
    result=$((result * 2))
done

# Run the binary program with powers of 2 as input and redirect the output to a file
output_file="output.txt"
rm -f "$output_file"

for power in "${powers_of_2[@]}"; do
    ../target/release/examples/local_plonk_test "$power" >> "$output_file"
done

echo "Output has been written to $output_file"